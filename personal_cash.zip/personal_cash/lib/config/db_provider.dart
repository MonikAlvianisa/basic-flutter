import 'package:personal_cash/components/cash_component.dart';
import 'package:sqflite/sqflite.dart'; //sqflite package
import 'package:path_provider/path_provider.dart'; //path_provider package
import 'package:path/path.dart'; //used to join paths
import '../models/cash_input_model.dart'; //import model class
import 'dart:io';
import 'dart:async';

class MemoDbProvider {
  Future<Database> init() async {
    Directory directory =
        await getApplicationDocumentsDirectory(); //returns a directory which stores permanent files
    final path =
        join(directory.path, "personal_cash.db"); //create path to database

    return await openDatabase(
        //open the database or create a database if there isn't any
        path,
        version: 6, onCreate: (Database db, int version) async {
      await db.execute("""
        CREATE TABLE IF NOT EXISTS kasmasuk(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          'createdAt' TEXT,
          'updatedAt' TEXT,
          description TEXT,
          amount REAL
          )""");
    });
  }

  Map<String, dynamic> toMap(
      String createdAt, String updatedAt, String description, double amount) {
    return <String, dynamic>{
      "createdAt": createdAt,
      "updatedAt": updatedAt,
      "description": description,
      "amount": amount,
    };
  }

  Future<int> addKasMasuk(String createdAt, String updatedAt, String description, double amount) async {
    final db = await init();
    return db.insert(
      "kasmasuk",
      toMap(createdAt, updatedAt, description, amount),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<CashInputModel>> fetchKasMasuk() async {
    final db = await init();
    final maps = await db
        .query("kasmasuk"); //query all the rows in a table as an array of maps
    return List.generate(maps.length, (i) {
      //create a list of memos
      return CashInputModel(
          createdAt: maps[i]['createdAt'],
          updatedAt: maps[i]['updatedAt'],
          description: maps[i]['description'],
          amount: maps[i]['amount']);
    });
  }
}
