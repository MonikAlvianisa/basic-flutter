class CashInputModel {
  String? updatedAt;
  String? createdAt;
  String? description;
  double? amount;

  CashInputModel({
    this.updatedAt,
    this.createdAt,
    this.description,
    this.amount,
  });
}
