import 'package:flutter/material.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:intl/intl.dart';
import "../config/db_provider.dart";
import 'package:line_icons/line_icons.dart';

class AddCashComponent extends StatefulWidget {
  const AddCashComponent({Key? key}) : super(key: key);

  @override
  _AddCashComponentState createState() => _AddCashComponentState();
}

class _AddCashComponentState extends State<AddCashComponent> {
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController amountController = TextEditingController();
  String? createdAt;
  String? updatedAt;
  MemoDbProvider dbProvider = MemoDbProvider();

  void saveDataToDatabase(BuildContext context) {
    // ScaffoldMessenger.of(context).showSnackBar(
    //   SnackBar(
    //     content: Text(descriptionController.text),
    //   ),
    // );

    dbProvider.addKasMasuk(createdAt!, updatedAt!, descriptionController.text,
        double.parse(amountController.text));
    Navigator.of(context).pop(1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Cash'),
      ),
      body: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          child: Column(
            children: [
              DateTimeField(
                decoration: const InputDecoration(
                  labelText: 'Created At',
                  border: OutlineInputBorder(),
                  errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.red, width: 5)),
                ),
                format: DateFormat('yyyy-MM-dd'),
                onChanged: (date) => setState(() {
                  createdAt = date.toString();
                }),
                onShowPicker: (context, currentValue) {
                  return showDatePicker(
                      context: context,
                      firstDate: DateTime(1900),
                      initialDate: currentValue ?? DateTime.now(),
                      lastDate: DateTime(2100));
                },
              ),
              const SizedBox(height: 20),
              DateTimeField(
                decoration: const InputDecoration(
                  labelText: 'Updated At',
                  border: OutlineInputBorder(),
                  errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.red, width: 5)),
                ),
                format: DateFormat('yyyy-MM-dd'),
                onChanged: (date) => setState(() {
                  updatedAt = date.toString();
                }),
                onShowPicker: (context, currentValue) {
                  return showDatePicker(
                      context: context,
                      firstDate: DateTime(1900),
                      initialDate: currentValue ?? DateTime.now(),
                      lastDate: DateTime(2100));
                },
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: descriptionController,
                keyboardType: TextInputType.text,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  border: OutlineInputBorder(),
                  errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.red, width: 5)),
                ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Amount',
                  border: OutlineInputBorder(),
                  errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.red, width: 5)),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.green,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  // radius: BorderRadius.circular(20),
                ),
                onPressed: () {
                  // Using the navigator to push a named route
                  saveDataToDatabase(context);
                },
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: const [
                    Icon(
                      // <-- Icon
                      LineIcons.plus,
                      size: 24.0,
                      color: Colors.white,
                    ),

                    Text('Save',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        )), // <-- Text
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
              ),
            ],
          )),
    );
  }
}
