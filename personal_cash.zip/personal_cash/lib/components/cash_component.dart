import 'package:flutter/material.dart';
import 'package:personal_cash/components/add_cash_component.dart';
import "../models/cash_input_model.dart";
import "../config/db_provider.dart";
import "dart:async";

class CashComponent extends StatefulWidget {
  const CashComponent({Key? key}) : super(key: key);

  @override
  _CashComponentState createState() => _CashComponentState();
}

class _CashComponentState extends State<CashComponent> {
  MemoDbProvider dbProvider = MemoDbProvider();
  List<CashInputModel> listCashInput = [];

  void initState() {
    super.initState();
    getDataFromDatabase();
  }

  FutureOr refreshBack(dynamic value) {
    setState(() {});
  }

  Future<List<CashInputModel>> getDataFromDatabase() async {
    var response = await dbProvider.fetchKasMasuk();
    return response;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kas Masuk'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
                  MaterialPageRoute(builder: (context) => AddCashComponent()))
              .then((value) => Future(() {
                    setState(() {});
                  }));
        },
        backgroundColor: Colors.blue,
        child: Icon(Icons.add),
      ),
      body: RefreshIndicator(
        child: _dataKasmasuk(context),
        onRefresh: () {
          return Future(() {
            setState(() {});
          });
        }
      ),
    );
  }

  Widget _dataKasmasuk(BuildContext context) {
    return SafeArea(
      child: FutureBuilder(
        future: getDataFromDatabase(),
        builder: (BuildContext context,
            AsyncSnapshot<List<CashInputModel>> snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Stack(
                children: <Widget>[Text("Terjadi Kesalahan...")],
              ),
            );
          } else if (snapshot.connectionState == ConnectionState.done) {
            listCashInput = snapshot.data!;
            return Container(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                child: ListView.builder(
                  itemBuilder: (context, index) {
                    CashInputModel datas = listCashInput[index];
                    return Card(
                      child: ListTile(
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(datas.createdAt!,
                                style: TextStyle(
                                    color: Colors.black45, fontSize: 14)),
                            Text(datas.updatedAt!,
                                style: TextStyle(
                                    color: Colors.black45, fontSize: 14))
                          ],
                        ),
                        subtitle: Row(
                          children: <Widget>[
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(datas.description!,
                                    style: TextStyle(color: Colors.black)),
                                Text(datas.amount.toString(),
                                    style: TextStyle(color: Colors.red)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  itemCount: listCashInput.length,
                ),
              ),
            );
          } else {
            return Center(
              child: CircularProgressIndicator(
                valueColor: new AlwaysStoppedAnimation<Color>(Colors.red[500]!),
              ),
            );
          }
        },
      ),
    );
  }
}
