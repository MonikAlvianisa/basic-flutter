import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';

import "./cash_component.dart";

class HalamanUtama extends StatefulWidget {
  const HalamanUtama({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _HalamanUtamaState createState() => _HalamanUtamaState();
}

class _HalamanUtamaState extends State<HalamanUtama> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      fit: StackFit.expand,
      children: [
        Column(children: [
          Expanded(
              flex: 3,
              child: Container(
                  width: MediaQuery.of(context).size.width,
                  color: Colors.blueGrey.shade500,
                  child: Container(
                    width: double.infinity,
                    height: 350.0,
                    child: Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          CircleAvatar(
                            backgroundImage:
                                AssetImage('lib/assets/images/image.jpg'),
                            radius: 50.0,
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          Text(
                            "Rades Pratama",
                            style: TextStyle(
                              fontFamily: "Outfit",
                              fontSize: 22.0,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ))),
          Expanded(
              flex: 7,
              child: Container(
                width: MediaQuery.of(context).size.width,
                color: Colors.white,
                child: Container(
                  padding: const EdgeInsets.only(top: 80, left: 10, right: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SizedBox(
                          height: 100,
                          width: MediaQuery.of(context)
                              .size
                              .width, // specific value
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: Colors.green,
                              // radius: BorderRadius.circular(20),
                            ),
                            onPressed: () {
                              // Using the navigator to push a named route
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CashComponent()));
                            },
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: const [
                                Icon(
                                  // <-- Icon
                                  LineIcons.download,
                                  size: 24.0,
                                  color: Colors.white,
                                  
                                ),
                                Text('Kas Masuk'), // <-- Text
                                SizedBox(
                                  width: 5,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 16,
                      ),
                    ],
                  ),
                ),
              ))
        ]),
        Positioned(
            top: MediaQuery.of(context).size.height * 0.2,
            left: 20,
            right: 20,
            child: Card(
              margin:
                  const EdgeInsets.symmetric(horizontal: 20.0, vertical: 60.0),
              clipBehavior: Clip.antiAlias,
              color: Colors.white,
              elevation: 5.0,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8.0, vertical: 22.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: const [
                          Text(
                            "Kas Masuk",
                            style: TextStyle(
                              color: Colors.redAccent,
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 5.0,
                          ),
                          Text(
                            "1200",
                            style: TextStyle(
                              fontSize: 20.0,
                              color: Colors.pinkAccent,
                            ),
                          )
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: const [
                          Text(
                            "Kas Keluar",
                            style: TextStyle(
                              color: Colors.redAccent,
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 5.0,
                          ),
                          Text(
                            "21.2K",
                            style: TextStyle(
                              fontSize: 20.0,
                              color: Colors.pinkAccent,
                            ),
                          )
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: const [
                          Text(
                            "Sisa Kas",
                            style: TextStyle(
                              color: Colors.redAccent,
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 5.0,
                          ),
                          Text(
                            "1200",
                            style: TextStyle(
                              fontSize: 20.0,
                              color: Colors.pinkAccent,
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ))
      ],
    ));
  }
}
